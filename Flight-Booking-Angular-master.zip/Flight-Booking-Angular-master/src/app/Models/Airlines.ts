import { FlightDetails } from "./FlightDetails";

export class Airlines{
    airlinesId!: string;
    airlineName!: string;
    airlineLogo!: string;
    blocked!: boolean;
    Flights!: FlightDetails[];
    
}