export class passengerdetails {
    id!: number;
    name!: string;
    age!: string;
    gender?: string;
    usermail?: string;
    pnrnumber!: number;
    mealpreference!: string;
    selectedseatnumber!: string;
    flightbookingid!: number;
   }