export class User{
    userID!:number;
    password!: string;
    role!: string;
    userEmail!: string;
    username!: string;
}
