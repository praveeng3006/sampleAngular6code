export class SearchFlights {
    
    FromPlace!: string;
    ToPlace!: string;
    AvailableDate!: Date;
    returnDateTime!: Date;
    StartDateTime!: Date;
    EndDateTime!: Date;
    TripType!: string;
    
}