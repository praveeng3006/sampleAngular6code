import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-discounts',
  templateUrl: './manage-discounts.component.html',
  styles: [
  ]
})
export class ManageDiscountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
