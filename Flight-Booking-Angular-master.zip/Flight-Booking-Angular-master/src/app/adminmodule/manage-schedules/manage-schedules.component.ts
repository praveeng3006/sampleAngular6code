import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-schedules',
  templateUrl: './manage-schedules.component.html',
  styles: [
  ]
})
export class ManageSchedulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
