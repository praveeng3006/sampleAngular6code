import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-airlines',
  templateUrl: './manage-airlines.component.html',
  styles: [
  ]
})
export class ManageAirlinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
