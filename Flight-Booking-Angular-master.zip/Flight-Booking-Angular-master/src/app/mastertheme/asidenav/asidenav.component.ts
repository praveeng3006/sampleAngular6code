import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asidenav',
  templateUrl: './asidenav.component.html',
  styles: [
  ]
})
export class AsidenavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
