import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topna',
  templateUrl: './topna.component.html',
  styles: [
  ]
})
export class TopnaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
